#!/usr/bin/env python3
"""Reproduce the synthetic examples in the accompanying LVPR theory paper.

These are assumed-parameter, scalar transmission-line simulations, not
measurements of a real 380 V cable and not an energized-line interface.
Dependencies: numpy, scipy, matplotlib. Run: python simulate_tdr.py
"""
from __future__ import annotations
import csv
import heapq
import json
from pathlib import Path
import numpy as np
from scipy import fft
from scipy.stats import norm
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parent
FIG = ROOT / 'figures'; RES = ROOT / 'results'
FIG.mkdir(exist_ok=True); RES.mkdir(exist_ok=True)
V = 1.7e8                  # assumed propagation velocity, m/s
FS = 1e9                   # sample rate, samples/s
DT = 1 / FS
TR_SOURCE = 5e-9           # source's 10-90% rise time, before receiver
TAU_G = TR_SOURCE / np.log(9)
TAU_R = 1 / (2 * np.pi * 100e6)  # single-pole 100 MHz receiver
ALPHA = 0.002              # assumed one-way amplitude attenuation, Np/m
SEED = 3802026


def step_response(t: np.ndarray) -> np.ndarray:
    """Unit step through two causal, first-order low-pass systems."""
    z = np.maximum(np.asarray(t, dtype=float), 0.0)
    ans = 1 - (TAU_G*np.exp(-z/TAU_G) - TAU_R*np.exp(-z/TAU_R))/(TAU_G-TAU_R)
    return np.where(np.asarray(t) >= 0, ans, 0.0)


def pulse(t: np.ndarray, width: float) -> np.ndarray:
    if width <= 0:
        raise ValueError('Pulse width must be positive.')
    return step_response(t) - step_response(np.asarray(t) - width)


def savefig(name: str) -> None:
    plt.tight_layout(pad=1.2)
    plt.savefig(FIG / (name + '.png'), dpi=200)
    plt.savefig(FIG / (name + '.svg'))
    plt.close()


def network_echoes(branch_b_m: int, branch_b_gamma: float,
                   alpha: float = 0.0, max_path_m: int = 1200) -> list[tuple[float,float]]:
    """Equal-impedance, three-port junction; matched source.

    Trunk=40m, branch A=80m/open, branch B specified by arguments.
    Path length is accumulated in integer metres to exactly combine
    coincident arrivals. Each transmission attenuates by exp(-alpha*length).
    The returned list is (roundtrip time in seconds, voltage coefficient).
    All junction re-reflections within max_path_m are included.
    """
    lens = (40,80,int(branch_b_m)); ends = (0.0,1.0,float(branch_b_gamma))
    pending: dict[int,np.ndarray] = {40:np.array([np.exp(-alpha*40),0.0,0.0])}
    heap = [40]; echoes: dict[int,float] = {}
    while heap:
        distance = heapq.heappop(heap)
        arrivals = pending.pop(distance)
        outgoing = (2/3)*np.sum(arrivals) - arrivals
        to_source = distance + lens[0]
        if to_source <= max_path_m:
            echoes[to_source] = echoes.get(to_source,0.0) + outgoing[0]*np.exp(-alpha*lens[0])
        for k in (1,2):
            nxt = distance + 2*lens[k]
            amplitude = outgoing[k]*ends[k]*np.exp(-2*alpha*lens[k])
            if nxt <= max_path_m and abs(amplitude) > 1e-13:
                if nxt not in pending:
                    pending[nxt] = np.zeros(3); heapq.heappush(heap,nxt)
                pending[nxt][k] += amplitude
    return [(d/V,a) for d,a in sorted(echoes.items()) if abs(a)>1e-12]


def make_figures() -> None:
    t = np.arange(0,3.2e-6,DT)
    x=123.4; y=np.exp(-2*ALPHA*x)*pulse(t-2*x/V,20e-9)
    plt.figure(figsize=(7.0,3.3))
    plt.plot(t*1e6,y,label='Open: voltage reflection positive')
    plt.plot(t*1e6,-y,label='Short: voltage reflection negative')
    plt.xlim(1.40,1.55); plt.xlabel('Round-trip delay (microseconds)')
    plt.ylabel('Reflected voltage (V)'); plt.legend(fontsize=9); plt.grid(True,alpha=.25)
    savefig('01_open_short')

    t=np.arange(0,1.4e-6,DT)
    plt.figure(figsize=(7.0,3.3))
    for width,offset in [(10e-9,0),(100e-9,.27)]:
        y=.15*pulse(t-2*60/V,width)+.12*pulse(t-2*63/V,width)
        plt.plot(t*V/2,y+offset,label=f'{width*1e9:.0f} ns pulse; vertical offset {offset:.2f} V')
    plt.xlim(55,78); plt.xlabel('Equivalent one-way distance (m)'); plt.ylabel('Voltage + stated offset (V)')
    plt.legend(fontsize=9); plt.grid(True,alpha=.25); savefig('02_pulse_overlap')

    t=np.arange(0,6e-6,DT)
    plt.figure(figsize=(7.0,3.6))
    for length,gamma,label in [(120,1,'Healthy: both branch ends open'),(60,-1,'Fault: short 60 m into branch B')]:
        out=sum((a*pulse(t-delay,20e-9) for delay,a in network_echoes(length,gamma)),np.zeros_like(t))
        plt.plot(t*V/2,out,label=label)
    plt.xlim(0,330); plt.xlabel('Equivalent distance = delay x v / 2 (m)')
    plt.ylabel('Reflected / incident voltage'); plt.legend(fontsize=9)
    plt.grid(True,alpha=.25); savefig('03_branched_network')

    # Voltage/current decomposition with a deliberately mismatched channel delay.
    t=np.arange(-20e-9,130e-9,.1e-9)
    vg=pulse(t,20e-9); current_delayed=pulse(t-.5e-9,20e-9)/50
    residual=(vg-50*current_delayed)/2
    plt.figure(figsize=(7.0,3.2))
    plt.plot(t*1e9,vg,label='Incident pulse (V)')
    plt.plot(t*1e9,residual,label='False reflected voltage: 0.5 ns V/I skew')
    plt.xlim(-5,45); plt.xlabel('Time (ns)'); plt.ylabel('Voltage (V)')
    plt.legend(fontsize=9); plt.grid(True,alpha=.25); savefig('04_deskew')


def monte_carlo(trials_per_polarity: int=500) -> list[dict]:
    """Blind signed matched-filter search, known white-noise standard deviation.

    Six widths, two noise levels, and both fault polarities; 12,000 total
    independent traces at the default setting. Fractional-lag parabolic
    interpolation follows the largest absolute normalized correlation.
    """
    rng=np.random.default_rng(SEED)
    n=14000; t=np.arange(n)*DT; x=750.0; delay=2*x/V
    amp=float(np.exp(-2*ALPHA*x)); threshold=6.0
    minlag=int(np.ceil(2*50/V/DT)); maxlag=int(np.floor(2*950/V/DT))
    nlooks=maxlag-minlag+1; rows=[]
    for sigma in [.02,.04]:
        for width_ns in [5,10,20,50,100,200]:
            width=width_ns*1e-9
            q=pulse(np.arange(int(np.ceil((width+40e-9)/DT))+1)*DT,width)
            m=len(q); nfft=fft.next_fast_len(n+m-1)
            qfft=fft.rfft(q[::-1],nfft)
            energy=float(q@q); lo=(m-1)+minlag; hi=(m-1)+maxlag+1
            errs=[]; qualified=[]; hits=0; correct=0; wrong_sign=0
            for sign in [1.,-1.]:
                truth=sign*amp*pulse(t-delay,width)
                remaining=trials_per_polarity
                while remaining:
                    b=min(50,remaining); remaining-=b
                    ys=truth[None,:]+rng.normal(0,sigma,(b,n))
                    corr=fft.irfft(fft.rfft(ys,nfft,axis=1)*qfft[None,:],nfft,axis=1)
                    z=corr[:,lo:hi]/(sigma*np.sqrt(energy))
                    idx=np.argmax(np.abs(z),axis=1); ix=np.arange(b)
                    peaks=z[ix,idx]; accepted=np.abs(peaks)>=threshold
                    # Fit signed peaks after orienting every peak upward.
                    jj=idx+lo; sgn=np.sign(peaks)
                    c0=corr[ix,jj]*sgn; cm=corr[ix,jj-1]*sgn; cp=corr[ix,jj+1]*sgn
                    den=cm-2*c0+cp
                    frac=np.divide(.5*(cm-cp),den,out=np.zeros(b),where=np.abs(den)>1e-14)
                    frac=np.clip(frac,-.5,.5)
                    xhat=(jj-(m-1)+frac)*DT*V/2
                    err=np.abs(xhat-x)
                    right_sign=np.sign(peaks)==sign
                    ok=accepted & right_sign & (err<=2.0)
                    hits+=int(accepted.sum()); correct+=int(ok.sum())
                    wrong_sign+=int((accepted & ~right_sign).sum())
                    errs.extend(err[accepted].tolist()); qualified.extend(err[ok].tolist())
            total=2*trials_per_polarity
            row={'noise_rms_mV':int(sigma*1000),'width_ns':width_ns,'trials':total,
                 'detected_count':hits,'correct_within_2m_count':correct,
                 'detection_pct':100*hits/total,'correct_within_2m_pct':100*correct/total,
                 'wrong_polarity_count':wrong_sign,
                 'median_error_detected_m':float(np.median(errs)) if errs else None,
                 'p95_error_detected_m':float(np.percentile(errs,95)) if errs else None,
                 'template_energy_samples':energy,
                 'nominal_matched_filter_snr_dB':float(10*np.log10(amp**2*energy/sigma**2))}
            rows.append(row)
    with (RES/'monte_carlo.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    summary={'seed':SEED,'velocity_m_per_s':V,'sampling_rate_Hz':FS,'source_rise_time_s':TR_SOURCE,
             'receiver_bandwidth_Hz':100e6,'alpha_Np_per_m':ALPHA,'fault_distance_m':x,
             'fault_return_amplitude_V':amp,'threshold':threshold,'search_min_m':50,'search_max_m':950,
             'search_lags':nlooks,'white_noise_union_bound_false_alarm_per_trace':float(2*nlooks*norm.sf(6)),
             'total_trials':len(rows)*2*trials_per_polarity,'results':rows}
    (RES/'summary.json').write_text(json.dumps(summary,indent=2))
    plt.figure(figsize=(7.0,3.4))
    for sigma in [20,40]:
        rs=[r for r in rows if r['noise_rms_mV']==sigma]
        plt.plot([r['width_ns'] for r in rs],[r['correct_within_2m_pct'] for r in rs],marker='o',label=f'{sigma} mV RMS white noise')
    plt.xscale('log');plt.xticks([5,10,20,50,100,200],['5','10','20','50','100','200'])
    plt.ylim(-2,103);plt.xlabel('Transmitted pulse width (ns)');plt.ylabel('Correct detection within 2 m (%)')
    plt.legend(fontsize=9);plt.grid(True,alpha=.25);savefig('05_detection')
    plt.figure(figsize=(7.0,3.4))
    for sigma in [20,40]:
        rs=[r for r in rows if r['noise_rms_mV']==sigma and r['detected_count']>0]
        plt.plot([r['width_ns'] for r in rs],[r['p95_error_detected_m'] for r in rs],marker='o',label=f'{sigma} mV RMS; detected traces only')
    plt.xscale('log');plt.xticks([5,10,20,50,100,200],['5','10','20','50','100','200'])
    plt.xlabel('Transmitted pulse width (ns)');plt.ylabel('95th percentile location error (m)')
    plt.legend(fontsize=9);plt.grid(True,alpha=.25);savefig('06_timing')
    return rows


def sanity_checks() -> None:
    p=pulse(np.arange(-10e-9,500e-9,.1e-9),20e-9)
    assert np.min(p)>-1e-12 and np.max(p)<=1+1e-12
    lossless=dict((round(t*V/2,6),a) for t,a in network_echoes(120,1))
    faulted=dict((round(t*V/2,6),a) for t,a in network_echoes(60,-1))
    assert np.isclose(lossless[40.0],-1/3)
    assert np.isclose(lossless[120.0],4/9)
    assert np.isclose(faulted[100.0],-4/9)
    # Identical branches are permutation-invariant at the source.
    S=np.full((3,3),2/3)-np.eye(3)
    assert np.allclose(S.T@S,np.eye(3))
    print('Analytical checks passed: pulse causality, node energy conservation, first echo amplitudes.')

if __name__=='__main__':
    sanity_checks();make_figures();rows=monte_carlo()
    for r in rows:
        print(r['noise_rms_mV'],r['width_ns'],r['correct_within_2m_pct'],r['p95_error_detected_m'])
    print('Saved figures and reproducible results to',ROOT)
