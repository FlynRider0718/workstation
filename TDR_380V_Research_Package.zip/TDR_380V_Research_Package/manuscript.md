::: {custom-style="Cover Kicker"}
ELECTRICAL MEASUREMENT · TRANSMISSION-LINE DIAGNOSTICS
:::

::: {custom-style="Cover Title"}
Fault Detection and Localization in Three-Phase 380 V Parallel Power Lines
:::

::: {custom-style="Cover Subtitle"}
Low-Voltage Pulse Reflectometry (Radar Method): Theory, Sensing Architecture, and Reproducible Simulation
:::

::: {custom-style="Cover Meta"}
A master's-level theoretical research paper

Prepared for Nata · 11 October 2026
:::

::: {custom-style="Cover Note"}
Scope: open circuits, short circuits, conductor coupling, and parallel-feeder ambiguity.

Research status: theoretical analysis and synthetic simulations. No measurements of the user's installation or energized-line hardware validation are claimed.
:::

# Abstract

Low-voltage pulse reflectometry (LVPR), commonly called time-domain reflectometry (TDR) or the cable radar method, estimates the electrical distance to an impedance discontinuity from the round-trip travel time of an injected signal. Its application to a three-phase 380 V power line requires more than selection of a pulse width. The return path, multiconductor coupling, feeder topology, instrument response, and propagation-velocity calibration jointly determine whether a reflected signal can be detected, classified, and assigned to a unique physical location.

This paper develops an analytical framework for isolated, de-energized power lines. A scalar distributed-parameter model establishes the distance and reflection equations. A multiconductor extension describes modal propagation and fault-induced mode conversion. Separate models are given for terminal loads, local shunt faults, series discontinuities, branch junctions, and electrically parallel feeders. The measurement architecture is evaluated using voltage sensing, directional bridges, high-frequency current transformers, Rogowski coils, and capacitive pickups. A practical design is proposed around calibrated voltage reflectometry, adjustable pulse widths, and optional simultaneous voltage-current sensing.

Reproducible simulations examine ideal open/short signatures, overlapping pulses, repeated reflections in a branched network, channel timing mismatch, and a signed matched-filter detector. In an explicitly assumed 750 m scalar-line example, 12,000 synthetic traces are evaluated. With a 1 V incident pulse, 5 ns source rise time, 100 MHz single-pole receiver, and 20 mV RMS independent sampled noise, correct detection within 2 m rises from 2.3% for a 5 ns pulse to 100% of the simulated trials for a 20 ns pulse. At 40 mV RMS, the corresponding transition occurs at a wider pulse: 21.5% at 20 ns and 100% at 50 ns. These are model-dependent observations, not cable specifications or guaranteed detection probabilities.

The principal conclusion is that pulse duration should be selected by a detection-and-resolution constraint, not by the nominal 380 V rating. A second conclusion is that some parallel-network ambiguities are structural: improved bandwidth cannot identify a branch when distinct faults generate the same accessible-port response. A validation protocol and uncertainty budget are provided to convert the theory into a defensible laboratory investigation.

**Keywords:** low-voltage pulse reflection; TDR; three-phase power line; open-circuit fault; short-circuit fault; multiconductor transmission line; HFCT; fault localization; measurement uncertainty.

**Interpretation and evidence boundary.** “380 V” is treated as the nominal RMS line-to-line service voltage. The supply frequency, cable construction, length, grounding arrangement, and exact meaning of “parallel” were not supplied. The paper therefore distinguishes adjacent phase conductors, branched feeders, and feeders connected in parallel at both ends. All numerical cable parameters are declared assumptions. The work is a thesis-style study, not an institution-approved thesis or an experimentally validated product design.

# Contents

| Section | Page in the supplied PDF |
|:---|---:|
| Abstract | 2 |
| Symbols and terminology | 4 |
| 1. Introduction and research problem | 5 |
| 2. Reflection-measurement methods and literature | 7 |
| 3. Distributed and multiconductor transmission-line theory | 9 |
| 4. Fault signatures and parallel-network ambiguity | 12 |
| 5. Pulse design, bandwidth, and timing limits | 15 |
| 6. Sensors and measurement architecture | 18 |
| 7. Calibration and fault-location algorithm | 21 |
| 8. Reproducible simulations and analytical results | 24 |
| 9. Experimental validation, uncertainty, and safety | 28 |
| 10. Discussion and conclusions | 30 |
| Appendix A. Worked initial design example | 31 |
| Appendix B. Reproduction and data provenance | 32 |
| References | 33 |

# Symbols and terminology

| Symbol | Meaning | Unit or convention |
|:---|:---|:---|
| $x,\ell$ | One-way distance; cable-section length | m |
| $v, v_m$ | Calibrated propagation speed; modal speed | m/s |
| $t_0,\tau$ | Instrument reference delay; fault round-trip delay | s |
| $T_p,t_r$ | Pulse duration; 10–90% rise time | s |
| $f_s,B$ | Sampling rate; analog bandwidth | samples/s; Hz |
| $R',L',G',C'$ | Scalar per-unit-length parameters | Ω/m; H/m; S/m; F/m |
| $\mathbf R,\mathbf L,\mathbf G,\mathbf C$ | Multiconductor per-unit-length matrices | Corresponding units above |
| $Z_0,\mathbf Y_c$ | Scalar characteristic impedance; characteristic admittance matrix | Ω; S |
| $\gamma=\alpha+j\beta$ | Propagation constant | 1/m |
| $V^{\text{+}},V^{\text{-}}$ | Forward and reflected voltage waves | V |
| $\Gamma_V,\Gamma_I$ | Voltage and current reflection coefficients | Dimensionless |
| $R_f,R_s$ | Local shunt-fault and series-fault resistance | Ω |
| $p(t),q(t)$ | Transmitted waveform; calibrated received template | Defined in each model |
| $h(t),H(f)$ | Impulse response; frequency response | System dependent |
| $\sigma_n,N$ | Sampled noise standard deviation; averaging count | V; dimensionless |
| $u_x,u_v,u_\tau$ | Standard uncertainties in distance, speed, and delay | m; m/s; s |

**LVPR and TDR.** Here these names denote an active electrical reflectometry measurement: the instrument injects a low-amplitude waveform and measures its reflection. “Radar” is an analogy to echo ranging; the pulse travels along conductors rather than being intentionally radiated into free space. [1]

**Fault detection, classification, and localization are separate tasks.** Detection establishes a statistically significant change. Classification assigns an electrical fault model. Localization estimates distance and, where identifiable, the affected branch or conductor. A system may succeed at one task and fail at another.

**Resolution is not accuracy.** Two-event separation, minimum visible distance, distance-display increment, repeatability, and absolute location uncertainty must be stated separately. A finely interpolated cursor is not evidence of equally fine absolute accuracy. [2,3]

**Voltage polarity convention.** A positive incident voltage is launched in the selected differential port. Port current is positive toward the line. Under this convention, an ideal terminal open has positive voltage reflection and an ideal terminal short has negative voltage reflection. The current-wave reflection has the opposite sign.

# 1. Introduction and research problem

## 1.1 Engineering motivation

The purpose of the proposed instrument is to identify an open circuit or short circuit and estimate its distance from an accessible end of a three-phase power line. A continuity measurement can indicate that a connection is broken, but does not by itself provide distributed distance information. LVPR adds spatial information by observing how a deliberately injected transient interacts with the line's high-frequency impedance. Cable ends, joints, changes of construction, and faults can all produce reflections; not every observed echo is a failure. [1]

A distribution line that is electrically short at its service frequency can be electrically long for a nanosecond transition. For example, the assumed propagation speed $1.7\times10^8$ m/s gives a 100 m one-way travel time of approximately 588 ns. A 5 ns voltage edge therefore encounters distributed transmission-line behavior rather than a single lumped resistance. This calculation explains why ordinary RMS voltage and current measurements do not describe the quantities needed by a pulse reflectometer.

The 380 V rating mainly establishes the service environment and electrical-safety problem. Once a line is isolated and verified de-energized, the reflectometry waveform is governed by its own amplitude and spectrum. The material and geometry influence propagation, whereas the nominal service voltage does not uniquely determine the appropriate pulse duration. Real instruments consequently offer selectable parameters and cable-dependent settings rather than one pulse duration for every cable of a particular voltage class. [3]

## 1.2 Definition of the system under study

Three configurations must be distinguished. In **configuration A**, the L1, L2, and L3 conductors simply run beside each other. They are not electrically joined. A selected conductor pair forms a differential test port, and the other conductors influence the measurement through electromagnetic coupling and their terminations. In **configuration B**, a feeder divides at a junction into two or more downstream routes. Junction reflections and multiple propagation paths are central. In **configuration C**, two feeders connect the same upstream and downstream buses. This produces parallel paths and potentially a loop, including the possibility that an intact route electrically masks a fault in another route.

The theoretical treatment covers all three configurations. The executable branched-network simulation is limited to configuration B with scalar, equal-impedance branches. The analytical multiconductor model addresses configuration A, while the identifiability analysis addresses configuration C. No claim is made that the supplied simulation is a full three-phase electromagnetic solver.

The primary operating condition is offline testing. Connected loads, converters, and other apparatus must be accounted for in the isolation plan and in the test model. This paper does not provide a mains-coupling circuit, insulation design, or permission to connect a laboratory generator or oscilloscope to an energized power line.

## 1.3 Research questions and contribution

The first question is how to relate pulse width, edge speed, analog bandwidth, and timing estimation to detection and localization performance. The second is how voltage and current transducers should be selected for a low-amplitude, fast reflection rather than for service-frequency power monitoring. The third is which fault models are valid for an open conductor, a phase-to-phase short, or a fault in a parallel feeder. The fourth is whether a given measurement arrangement can distinguish all candidate fault locations.

The contribution is an integrated design framework with explicit assumptions, derivations, reproducible scalar simulations, and an experimental validation plan. The established TDR principle, correlation methods, and model-based inference are not claimed as new discoveries. The engineering synthesis connects these methods to the user's three-phase application and highlights failure modes that a simple $x=v\tau/2$ calculation can conceal.

A useful research hypothesis is that increasing pulse duration can improve weak-echo detection without indefinitely improving isolated-edge timing precision. A second hypothesis is that calibrated modal or effective propagation speed matters more than sample interpolation for long-range absolute accuracy. A third proposition, established by symmetry in Section 4, is that no single-port algorithm can uniquely identify every fault in a symmetric parallel network.

## 1.4 Success criteria

A meaningful evaluation must report detection probability, false-alarm rate, open/short classification, branch-identification rate, and a distance-error distribution. Results should be stratified by cable type, distance, fault resistance, topology, and interference condition. “Accuracy” alone is insufficient: a very accurate estimate on a small fraction of detectable cases may be less useful than a slightly less precise system with reliable detection.

The proposed system is diagnostic equipment. It is not a substitute for circuit protection, an insulation-withstand test, or verification that an installation is safe to energize. An absent LVPR echo does not exclude a voltage-dependent fault that remains nonconductive at the test amplitude.

# 2. Reflection-measurement methods and literature

## 2.1 Established approaches

The measurement method specifies the excitation and reconstruction process; the sensor specifies how voltage or current is converted into an instrument signal. For example, “HFCT” describes a current transducer, not an alternative ranging algorithm. The same transducer could support pulse TDR, coded reflectometry, or transient monitoring if its transfer function and safety ratings are appropriate.

| Method | Excitation and measurement | Main benefit | Principal limitation |
|:---|:---|:---|:---|
| Pulse TDR / LVPR | Short voltage pulse; measure returning waveform | Direct interpretation of hard-fault echoes | Energy–overlap trade-off; launch feedthrough |
| Step TDR | Fast voltage step; observe reflected transitions | Strong emphasis on edge timing and impedance changes | Receiver recovery and slow settling still matter |
| Reference-difference TDR | Compare a new trace with an aligned healthy trace | Suppresses stable joints and known topology | Load or fixture changes can imitate a fault |
| STDR / SSTDR | Known sequence, optionally modulated; correlation | Processing gain and interference tolerance | Autocorrelation sidelobes and repeat ambiguities |
| Multicarrier reflectometry | Controlled frequency components; reconstruction | Spectrum can be shaped around constraints | Missing bands and calibration affect reconstruction |
| Time-frequency reflectometry | Chirp or localized waveform; time-frequency analysis | Joint use of delay and spectral information | More complicated processing and interpretation |
| FDR / VNA reflectometry | Measure complex reflection versus frequency; transform | Frequency-dependent impedance and calibrated phase | Sweep time, windowing, and unambiguous-range constraints |

The pulse/step distinction is important. A long pulse with a fast leading edge can still provide precise timing of an isolated discontinuity; the full pulse width is not an unconditional lower bound on that timing precision. Instrument pulse and step options illustrate why duration and edge response must be assessed separately. [2,3]

Smith, Furse, and Gunther analyze sequence and spread-spectrum techniques for wire-fault location, including signal-to-noise ratio, measurement latency, and operation alongside other signals. Their work provides a basis for considering coded excitation when single pulses have insufficient energy. Its aircraft-wiring results cannot be transferred directly to a 380 V industrial feeder with different coupling and noise conditions. [4]

Lelong and Carrion formulate multicarrier reflectometry to control the excitation spectrum and reconstruct network responses despite selected spectral restrictions. This is relevant when a future online instrument must coexist with other electrical activity. Spectrum control alone, however, does not establish mains safety or resolve an unknown physical topology. [5]

Song and colleagues investigate time-frequency-domain reflectometry for single and multiple wiring faults, with experimental comparisons on coaxial cable. This supports considering chirp-based processing as a later extension; it does not establish a universal advantage for every power cable or every pulse sensor. [6]

## 2.2 Network inference and model-based interpretation

Osman and colleagues investigate distributed reflectometers and data fusion for soft-fault identification in twisted-pair networks. Their approach is pertinent to branch ambiguity: additional observation points provide information that may be absent at one port. Their specific trained models and experimental setup should not be treated as a validated classifier for an unrelated three-phase installation. [7]

Schuet, Timucin, and Wheeler combine a forward scattering model with probabilistic inference for TDR-based wire-fault characterization. A particularly useful feature is the explicit treatment of instrument delay, source mismatch, gain, and uncertainty, rather than treating the trace as a fault echo alone. This motivates the calibrated forward-model approach adopted in this paper. [8]

The present study chooses direct pulse reflectometry as its baseline because open and low-resistance short faults generally give strong, interpretable impedance discontinuities under suitable test conditions. Coded excitation, frequency sweeps, and multiport inference are extensions, not prerequisites for demonstrating the basic offline method. [1,4]

## 2.3 Frequency-domain equivalence

For a linear time-invariant test configuration, a complex measured reflection spectrum $S_{11}(f)$ can be transformed into a time-domain reflectogram. The spectral bandwidth determines the temporal response width, while frequency spacing determines the periodicity of the transformed result. Windowing reduces ringing at the cost of broadening. Altering a display scale does not create missing measurement bandwidth. [13]

Using a conventional one-way fault-distance interpretation, the approximate relationships are

$$\Delta x_{\mathrm{response}}\sim\frac{v}{2B},\qquad T_{\mathrm{period}}=\frac{1}{\Delta f},\qquad x_{\mathrm{period}}=\frac{v}{2\Delta f}. \qquad (1)$$

The first expression has a waveform- and window-dependent numerical factor. The factor of two in distance follows from the round trip. Instrument distance-axis conventions should be checked explicitly, particularly when comparing a through measurement with a reflection measurement. Zero-padding can interpolate a transform, but cannot improve its underlying two-event resolution.

## 2.4 Active reflectometry versus passive fault transients

Passive travelling-wave fault location observes a transient created by a fault or switching event. Active LVPR injects a known test waveform. A fast voltage probe or HFCT may be useful in either arrangement, but their triggering, timing references, and inference problems differ. Likewise, partial-discharge sensing observes a discharge phenomenon rather than necessarily measuring the response to a deliberately injected low-voltage pulse.

For this project, the baseline measurement is the active, offline case. Online reflectometry remains a separate engineering project requiring a certified interface, interference analysis, and testing against the actual installation environment.

# 3. Distributed and multiconductor transmission-line theory

## 3.1 Scalar distributed-parameter model

Consider a selected forward conductor and return path. Let $R'$, $L'$, $G'$, and $C'$ denote their effective loop resistance, inductance, shunt conductance, and capacitance per unit length. Applying Kirchhoff's laws to an infinitesimal segment gives

$$\frac{\partial v(x,t)}{\partial x}=-R'i(x,t)-L'\frac{\partial i(x,t)}{\partial t}, \qquad (2)$$

$$\frac{\partial i(x,t)}{\partial x}=-G'v(x,t)-C'\frac{\partial v(x,t)}{\partial t}. \qquad (3)$$

These equations describe distributed propagation rather than merely the service-frequency impedance. The same RLGC transmission-line framework is used in network-reflectometry modeling. [7]

For sinusoidal components with angular frequency $\omega$, define

$$Z'(\omega)=R'+j\omega L',\qquad Y'(\omega)=G'+j\omega C'. \qquad (4)$$

The propagation constant and characteristic impedance are

$$\gamma(\omega)=\sqrt{Z'Y'}=\alpha+j\beta,\qquad Z_0(\omega)=\sqrt{Z'/Y'}. \qquad (5)$$

A passive branch of the square root is selected. In the low-loss, approximately nondispersive limit,

$$v\simeq\frac{1}{\sqrt{L'C'}},\qquad Z_0\simeq\sqrt{\frac{L'}{C'}}. \qquad (6)$$

The characteristic impedance is not the DC resistance of the cable. In particular, a power conductor with a small DC resistance is not automatically a low-impedance termination for a nanosecond pulse.

For a reflection coefficient $\Gamma_f(\omega)$ at distance $x$, an idealized reflection-only transfer function is

$$H_{\mathrm{echo}}(\omega)=\Gamma_f(\omega)e^{-2\gamma(\omega)x}. \qquad (7)$$

The factor of two represents forward and return travel. Instrument coupling, source re-reflections, and branch transmission factors must be added when relevant; Equation (7) is not the complete transfer function of an arbitrary test assembly.

## 3.2 Time of flight and the reference plane

With a known effective propagation speed and a calibrated timing origin,

$$\hat x=\frac{v}{2}(t_{\mathrm{echo}}-t_0)=\frac{v\tau}{2}. \qquad (8)$$

The reference plane should be the cable entrance, not an undocumented internal generator trigger. Adapters, test leads, sensor delay, and analog filters shift the observed timing. A fixed uncorrected delay $\delta t$ produces a distance bias $v\delta t/2$.

For a mixed route containing sections with different velocities,

$$\tau=2\sum_k\frac{\ell_k}{v_k}. \qquad (9)$$

Thus, a single effective speed converts travel time into physical distance only under a defined route model. Measurements from both accessible ends provide useful consistency checks, but do not remove the need to understand changes in cable construction. Manufacturer guidance also flags mixed routes as a special interpretation problem. [1]

## 3.3 Extension to multiple conductors

Let $\mathbf V$ and $\mathbf I$ contain conductor voltages and currents relative to a specified reference conductor or modeled return. For uniform sections,

$$\frac{\partial\mathbf V}{\partial x}=-\mathbf Z\mathbf I,\qquad \frac{\partial\mathbf I}{\partial x}=-\mathbf Y\mathbf V, \qquad (10)$$

where $\mathbf Z=\mathbf R+j\omega\mathbf L$ and $\mathbf Y=\mathbf G+j\omega\mathbf C$. Diagonal entries represent self terms; off-diagonal entries represent coupling. All entries are per unit length. The number of independent coordinates depends on the chosen conductor and return model, not just the label “three phase.”

Combining the equations gives

$$\frac{\partial^2\mathbf V}{\partial x^2}=\mathbf Z\mathbf Y\mathbf V. \qquad (11)$$

If the matrix is diagonalizable,

$$\mathbf Z\mathbf Y=\mathbf T_V\,\operatorname{diag}(\gamma_m^2)\,\mathbf T_V^{-1}. \qquad (12)$$

The columns of $\mathbf T_V$ define voltage modes. Each mode can have its own attenuation and phase response. In a lossless model, $v_m=1/\sqrt{\lambda_m(\mathbf L\mathbf C)}$. This is a matrix extension derived directly from Equations (2)–(3), not an assumption that all three phases propagate independently.

A symmetric construction may allow a common mode and two differential modes. In a homogeneous ideal TEM medium, modal velocities can coincide despite coupling. Different velocities are therefore possible, not inevitable. A conventional low-frequency phase transformation is not automatically the correct broadband modal calibration for an arbitrary cable geometry.

For a three-wire line without a neutral, the return must still be defined. A phase-to-phase test can use one selected conductor as the differential return, with the remaining conductor's boundary condition documented. In a model that includes earth, armor, or a screen, their impedance and coupling also need representation. A 380 V line-to-line rating does not by itself establish a 220 V phase-to-earth condition.

## 3.4 Modal termination and conversion

Define the characteristic admittance matrix by the forward-wave relation $\mathbf I^{\text{+}}=\mathbf Y_c\mathbf V^{\text{+}}$. With port current positive toward the load,

$$\mathbf V=\mathbf V^{\text{+}}+\mathbf V^{\text{-}},\qquad \mathbf I=\mathbf Y_c(\mathbf V^{\text{+}}-\mathbf V^{\text{-}}). \qquad (13)$$

For a termination $\mathbf I=\mathbf Y_L\mathbf V$, solving the boundary equation yields

$$\mathbf\Gamma_V=(\mathbf Y_c+\mathbf Y_L)^{-1}(\mathbf Y_c-\mathbf Y_L). \qquad (14)$$

Matrix order matters. A scalar reflection formula cannot be applied independently to phase entries without demonstrating decoupling. For the uniform section, one consistent construction is $\mathbf Y_c=\mathbf Z^{-1}\mathbf T_V\operatorname{diag}(\gamma_m)\mathbf T_V^{-1}$.

Opening every modal termination gives $\mathbf\Gamma_V=\mathbf I$; a complete short boundary gives the limiting result $-\mathbf I$. Opening only one conductor in a continuing network is different: it requires an internal connection boundary and can mix modes. Similarly, a phase-to-phase short imposes a voltage constraint between two conductors, rather than shorting every mode to the reference.

An unbalanced discontinuity can convert incident mode $a$ into returning mode $b$. The associated delay is

$$\tau_{ab}=\frac{x}{v_a}+\frac{x}{v_b}. \qquad (15)$$

Interpreting every such arrival with $2x/v_a$ can produce false distances. This is one reason to compare several phase-pair measurements or use a calibrated multiport model rather than label each peak as a separate fault.

## 3.5 An illustrative modal calculation

Consider the assumed symmetric matrices

$$\mathbf L=10^{-6}\begin{bmatrix}0.60&0.15&0.15\\0.15&0.60&0.15\\0.15&0.15&0.60\end{bmatrix}\ \mathrm{H/m}, \qquad (16)$$

$$\mathbf C=10^{-12}\begin{bmatrix}80&-10&-10\\-10&80&-10\\-10&-10&80\end{bmatrix}\ \mathrm{F/m}. \qquad (17)$$

These positive-definite matrices are a mathematical example, not measured cable data. They yield common-mode parameters $L_c=0.90$ μH/m and $C_c=60$ pF/m, and differential-mode parameters $L_d=0.45$ μH/m and $C_d=90$ pF/m. The corresponding speeds are approximately $1.361\times10^8$ and $1.571\times10^8$ m/s.

At 100 m, same-mode round-trip delays are approximately 1.470 μs and 1.273 μs. A perfectly balanced excitation proportional to $(1,-1,0)$ has no common-mode component in this ideal symmetric model. An unbalanced termination can nevertheless generate mode conversion. The example demonstrates why both the excitation vector and boundary conditions must be specified before selecting a velocity.

# 4. Fault signatures and parallel-network ambiguity

## 4.1 Ideal terminal open and short

For a scalar line terminated in $Z_L$, the load boundary $V=Z_L I$ and Equation (13)'s scalar form give

$$\Gamma_V=\frac{Z_L-Z_0}{Z_L+Z_0},\qquad \Gamma_I=-\Gamma_V. \qquad (18)$$

An ideal open has $Z_L\to\infty$, so $\Gamma_V=+1$. An ideal short has $Z_L\to0$, so $\Gamma_V=-1$. A matched load has $Z_L=Z_0$ and no terminal reflection. The familiar positive-open interpretation is used in practical cable reflectometry. [1]

![Figure 1. Synthetic reflection-only voltages for an open and a short at 123.4 m. Assumptions: 20 ns pulse, 1 V incident amplitude, v = 1.7 × 10^8 m/s, alpha = 0.002 Np/m, and the causal source/receiver model in Section 8.](figures/01_open_short.png){width=5.7in}

These signs assume the stated voltage orientation. Current sensing, inversion, bridges, and repeated reflections can change observed polarity. Classification therefore requires calibrated open/short references and a causal path model.

## 4.2 A local shunt fault is not a terminal resistor

Suppose a fault resistance $R_f$ is connected across a selected differential path at an internal point while the downstream line continues with characteristic impedance $Z_0$. Before any farther reflection returns, the impedance seen at the discontinuity is $Z_0\parallel R_f$. Substitution into Equation (18) gives

$$\Gamma_{\mathrm{shunt}}=-\frac{Z_0}{2R_f+Z_0}. \qquad (19)$$

For a series resistance $R_s$ inserted into an otherwise uniform line, the corresponding first reflection is

$$\Gamma_{\mathrm{series}}=\frac{R_s}{2Z_0+R_s}. \qquad (20)$$

A large *shunt* resistance can be almost invisible, whereas a large *series* resistance can look nearly open. These are scalar approximations for a defined mode or port, not universal phase-by-phase laws.

| Assumed condition, with Z₀ = 50 Ω | First voltage reflection coefficient |
|:---|---:|
| Terminal open | +1.000 |
| Terminal short | −1.000 |
| Local shunt $R_f=25$ Ω | −0.500 |
| Local shunt $R_f=100$ Ω | −0.200 |
| Local shunt $R_f=1$ kΩ | −0.0244 |
| Local shunt $R_f=10$ kΩ | −0.00249 |
| Local series $R_s=10$ Ω | +0.0909 |
| Local series $R_s=100$ Ω | +0.500 |

Inferring fault resistance requires correction for the incident waveform, gain, propagation loss, and junction transmission. A raw displayed peak is not generally $\Gamma_f$.

## 4.3 Finite damaged sections and voltage-dependent failures

A short altered-impedance section has an entrance and exit. Opposite-sign reflections can partly cancel when closely spaced, making weak damage difficult to detect even where a complete break would be obvious. Chafed-cable modeling illustrates why soft defects require more than the hard-open/hard-short interpretation. [8]

A fault that conducts only above a breakdown threshold may not be excited by a low-voltage pulse. Ordinary LVPR therefore cannot certify insulation condition merely because its trace appears normal. High-voltage fault-location or insulation-diagnostic procedures are separate specialist methods and are outside the proposed low-voltage laboratory design.

## 4.4 Reflection at a healthy branch junction

At a junction, an incoming line sees the parallel characteristic impedances of the outgoing paths until their remote reflections return. With incoming impedance $Z_0$ and $n$ identical outgoing lines of impedance $Z_0$,

$$Z_J=\frac{Z_0}{n},\qquad \Gamma_J=\frac{1-n}{1+n}. \qquad (21)$$

Two outgoing paths produce $\Gamma_J=-1/3$; three produce $-1/2$. A negative reflection at a healthy split must not automatically be classified as a short. This is an electrical branch calculation, not permission to join L1, L2, and L3 together.

For a node joining scalar lines with admittances $Y_k$, let $a_k$ be the voltage wave arriving from port $k$ and $b_k$ the outgoing voltage wave. Voltage continuity and current conservation give

$$V_J=2\frac{\sum_kY_k a_k}{\sum_kY_k},\qquad b_k=V_J-a_k. \qquad (22)$$

For three equal-impedance ports, the scattering matrix is $\mathbf S=(2/3)\mathbf 1\mathbf 1^T-\mathbf I$. The diagonal coefficient is $-1/3$, and transmission between different ports is $2/3$. The lossless matrix is energy-conserving under equal-impedance normalization, as checked by the supplied code.

## 4.5 First and repeated echoes

In the simulation topology, a 40 m trunk splits into an 80 m branch A and a 120 m branch B. Both healthy ends are open. The junction echo appears at an equivalent distance of 40 m. The first branch-end echoes appear at 120 m and 160 m, with coefficient $(2/3)(+1)(2/3)=4/9$ before attenuation.

When branch B is shorted 60 m beyond the junction, its first fault echo appears at an electrical distance of 100 m with coefficient $-4/9$. Subsequent returns can traverse one branch, scatter at the junction, traverse the other, and return again. An echo's equivalent distance may then represent a composite path rather than the physical position of another fault.

![Figure 2. Lossless scalar branched-network simulation, including repeated junction reflections. The negative event at 40 m is a healthy junction. The first short-circuit return is at 100 m. The horizontal axis is equivalent electrical distance, not a unique branch coordinate.](figures/03_branched_network.png){width=5.3in}

## 4.6 Identifiability of electrically parallel feeders

Consider electrically identical branches A and B between the same accessible buses. Hypotheses $H_A$ and $H_B$ place an identical fault at corresponding positions in A or B. Exchanging the labels leaves the accessible network unchanged, so

$$H_{\mathrm{input}}(f\mid H_A)=H_{\mathrm{input}}(f\mid H_B) \quad\text{for every measured }f. \qquad (23)$$

The branch label is unidentifiable at that input: additional samples or algorithmic complexity cannot recover absent information. Break the symmetry through safely isolated branch tests, branch-specific sensing, or a calibrated physical asymmetry. Measuring only the same common buses at both ends may remain ambiguous. Distributed sensing helps only when its placement supplies distinguishing information. [7]

# 5. Pulse design, bandwidth, and timing limits

## 5.1 Duration and edge speed are different design variables

A rectangular pulse of duration $T_p$ occupies a one-way equivalent length

$$\ell_p=\frac{vT_p}{2}. \qquad (24)$$

This is a useful pulse-overlap scale for simple pulse displays. It is not a universal location-accuracy limit. For an isolated edge, an analogous scale is $\ell_r\approx vt_{r,\mathrm{effective}}/2$, and the delay estimator can interpolate within that response when signal-to-noise ratio and model fidelity permit. Instrument rise time and fixturing affect the observed transition. [2]

| Pulse duration | Pulse-overlap scale at v = 1.7 × 10⁸ m/s |
|---:|---:|
| 5 ns | 0.425 m |
| 10 ns | 0.850 m |
| 20 ns | 1.700 m |
| 50 ns | 4.250 m |
| 100 ns | 8.500 m |
| 200 ns | 17.000 m |

![Figure 3. First-order synthetic echoes from two weak positive discontinuities at 60 m and 63 m. A 100 ns pulse produces more waveform overlap than a 10 ns pulse. Fast edges remain present; the example does not establish an absolute two-fault resolution limit.](figures/02_pulse_overlap.png){width=6.1in}

For a simple nonoverlapping-pulse interpretation of events separated by $\Delta x$, a conservative design condition is $T_p\lesssim2\Delta x/v$, with allowance for receiver and cable broadening. A model-based edge detector may work outside this condition, but it must be validated on the actual overlapping signatures.

## 5.2 Analog bandwidth and sampling

For a single-pole response, the 10–90% rise time is approximately

$$t_r\simeq\frac{0.35}{B}. \qquad (25)$$

The coefficient depends on response shape; it is not an exact law for every oscilloscope or probe. Instrument guidance explicitly relates bandwidth and transition response and discusses these limitations. [14]

A 100 MHz single-pole receiver contributes about 3.5 ns rise time. If several components have comparable bandwidth, their combined response is slower than any one component. A root-sum-square estimate of individual rise times is a useful approximation for suitable smooth responses, but a measured end-to-end impulse response is preferable when there is ringing, peaking, or dispersion.

The raw distance increment associated with sample spacing is

$$\Delta x_s=\frac{v}{2f_s}. \qquad (26)$$

At 1 GS/s and the assumed speed, this is 0.085 m. It is a grid interval, not a guaranteed error bound. A 500 MS/s or 1 GS/s digitizer is a reasonable proposed laboratory starting point for a roughly 100 MHz analog front end, with anti-alias filtering and characterized timing. The final requirement should follow from the measured pulse response rather than from the 380 V label.

## 5.3 Energy, noise, and pulse duration

For an approximately rectangular incident voltage pulse of amplitude $V_i$ on a real $Z_0$, the launched energy is approximately $E_p=V_i^2T_p/Z_0$. Increasing duration adds energy at fixed amplitude. In an ideal white-noise matched-filter measurement with a known waveform, detection performance improves with received waveform energy.

Timing information is different. For $y_n=Aq(t_n-\tau)+n_n$, independent Gaussian sample noise with variance $\sigma_n^2$, and unknown amplitude $A$, the local Fisher-information bound is

$$\operatorname{var}(\hat\tau)\geq\frac{\sigma_n^2}{A^2\left[\sum_n(q'_n)^2-\dfrac{(\sum_nq_nq'_n)^2}{\sum_nq_n^2}\right]}. \qquad (27)$$

This expression follows by eliminating the amplitude parameter from the two-parameter Fisher-information matrix. It is a local, regular-model bound, not a guarantee for a detector that can miss the echo. If the pulse is fully captured and its two edges no longer overlap, widening the flat plateau adds energy but little additional edge derivative energy. Detection may continue improving while isolated-delay precision approaches a plateau.

For $N$ coherently aligned repetitions with independent noise, averaging reduces noise standard deviation by $\sqrt N$. For example, 16 repetitions reduce the random-noise contribution by a factor of four. Correlated interference, timing drift, and deterministic echoes do not receive the same reduction. Coding provides another way to accumulate energy, but code sidelobes and periodicity must be considered. [4,5]

## 5.4 Near-end visibility and repetition interval

Define $t_{\mathrm{usable}}$ as the earliest delay after launch at which the receiver and feedthrough cancellation provide a valid measurement. Then an approximate near-end blind distance is $x_{\mathrm{blind}}=vt_{\mathrm{usable}}/2$. It depends on overload recovery, coupling, switching, and waveform overlap. It is not necessarily equal to $vT_p/2$.

The acquisition record must cover the longest relevant round trip and important repeated paths. At 1 km and the assumed speed, the direct round-trip delay is about 11.765 μs. A 20 μs record is a proposed initial direct-path window, but a branched or reflective network can require longer. The repetition interval must allow previous returns and front-end transients to decay sufficiently; 100 μs is only an illustrative starting value to be checked against measured ring-down.

## 5.5 Proposed selection rule

Choose the shortest available pulse that meets the required detection probability and false-alarm target over the required range, subject to the separation and near-end requirements. If no duration satisfies both detection and separation, improve averaging, receiver noise, source/receiver isolation, or the waveform family rather than simply widening the pulse indefinitely.

A useful initial sweep is 10, 20, 50, 100, 200, and 500 ns, with shorter settings only when the complete source and receiver preserve them. No distance-versus-pulse-width table should be treated as universal across unknown cable types. For the user's installation, cable geometry, length, actual echo attenuation, and the desired separation remain necessary inputs.

# 6. Sensors and measurement architecture

## 6.1 Recommended baseline

For an isolated low-voltage experiment, the preferred first architecture is a calibrated voltage reflectometer: a fast pulse source, known source impedance, reflection bridge or characterized launch node, and a low-loading broadband voltage receiver. The recommendation is an engineering judgment based on directly measuring the quantity used in the open/short voltage-reflection model. A commercial TDR is a useful independent reference, but its rating and operating manual must match the use case. [1–3]

The functional signal chain is: **pulse source → calibrated launch/bridge → selected conductor pair**. A separate bridge output or low-loading pickup feeds **protection appropriate to the isolated bench → broadband amplifier → anti-alias response → digitizer → calibration and inference**. Optional current sensing belongs at the same electrical reference plane as the voltage channel.

A bridge separates or suppresses the outgoing pulse so that a smaller return does not consume the entire receiver range. It is a coupling/separation network, not inherently a safety-isolation device. Its directivity, frequency response, source match, and recovery must be measured. A microwave coupler that excludes the low-frequency content of the chosen waveform is not automatically a good short-cable TDR bridge.

## 6.2 Sensor comparison

| Sensor or interface | Suitability for this project | Main specification to verify |
|:---|:---|:---|
| Broadband voltage bridge / low-loading active voltage receiver | Preferred primary offline measurement | End-to-end bandwidth, loading, noise, feedthrough rejection |
| Active differential voltage probe | Useful laboratory receiver across a defined pair | Differential and common-mode ranges; capacitance; CMRR versus frequency |
| High-frequency current transformer (HFCT) | Preferred optional fast-current channel | Transfer impedance, rise time, droop, aperture, current-time and RMS limits |
| Wideband Rogowski coil with integrator | Conditional; useful where aperture/current capability dominates | Complete coil-plus-integrator response, sensitivity, noise, output loading |
| Capacitive or electric-field pickup | Research option for non-galvanic coupling | Geometry-dependent transfer, shielding, reproducibility, insulation |
| Low-inductance current shunt | Useful isolated reference measurement | Added impedance, parasitic inductance, common-mode handling |
| Ordinary power-frequency CT, voltage transformer, clamp meter, or slow Hall module | Not a default choice for nanosecond pulses | Demonstrated broadband response is required; service-frequency accuracy is insufficient |

## 6.3 Voltage-probe loading and ratings

A high DC input resistance does not guarantee negligible nanosecond loading. For an otherwise matched line with a shunt input capacitance $C_p$, the local reflection is

$$\Gamma_p(s)=-\frac{sC_pZ_0}{2+sC_pZ_0}. \qquad (28)$$

This follows by replacing the local continuation impedance with $Z_0\parallel1/(sC_p)$. At 100 MHz and $Z_0=50$ Ω, 10 pF produces a reflection magnitude of approximately 0.155, whereas 1 pF produces approximately 0.0157. These are derived example values. The fixture capacitance and lead inductance matter as much as the nominal probe input resistance.

Tektronix lists the TDP1000 differential probe with 1 GHz bandwidth and differential input capacitance of approximately 1 pF, but its specified differential operating range is ±42 V DC plus peak AC and its common-mode range is also limited. It is an example of a low-loading fast laboratory probe, **not a probe to connect directly across an energized 380 V line**. The “high voltage” product wording must not replace reading its actual limits. [9]

A grounded oscilloscope input can create a hazardous unintended connection. Never float a grounded oscilloscope by defeating its protective earth. In addition, a bare 50 Ω scope input connected across the cable becomes a substantial shunt termination. A designed 50 Ω bridge output and a 50 Ω shunt on the cable are not the same circuit.

## 6.4 HFCT sensing

In its calibrated passband, an HFCT produces $V_{\mathrm{out}}(f)=Z_T(f)I(f)$, where $Z_T$ is its transfer impedance. The upper-band response controls edge fidelity; the lower-band response causes droop and baseline restoration. The sensor must be selected by the actual pulse spectrum and current rather than by its ability to measure a large service current.

The Pearson 2877 specification provides a concrete fast-current example: nominal sensitivity 1 V/A, approximately 200 MHz high-frequency −3 dB point, and 2 ns usable rise time. Its maximum RMS current is only 2.5 A. It is therefore a useful illustration for a low-current pulse fixture, not an automatically suitable clamp for a loaded power feeder. Output termination must follow the manufacturer's convention because loading changes the delivered voltage. [10]

Pearson also advises selecting a usable sensor rise time faster than the current pulse being observed. “Usable rise time” and a simple bandwidth-derived rise time need not be identical specifications. [11]

For differential current, a probe around the entire cable may see strong cancellation between outgoing and return currents. The isolated test fixture should place the sensor around an appropriate individual injection or return lead, with orientation recorded. Core saturation, large low-frequency current, and current-time product are separate limits; magnetic coupling does not automatically establish an acceptable installation-category safety rating.

## 6.5 Rogowski and capacitive sensing

An ideal Rogowski coil generates a signal proportional to $M\,di/dt$, so the complete current measurement requires integration. Its lack of a ferromagnetic core helps with saturation concerns, but the integrator introduces noise and frequency-response constraints. High-current capability is not synonymous with sensitivity to a small reflected pulse.

The PEM CWTMini50HF demonstrates that fast Rogowski systems exist: its manufacturer specifies up to 50 MHz bandwidth and 12.5 ns rise-time capability for the stated coil configuration. That is not equivalent to faithfully measuring a 5 ns transition. The manufacturer also specifies a high-impedance receiving load and does not recommend driving a 50 Ω load. This illustrates why the complete sensor system, not the coil alone, must be evaluated. [12]

A simplified capacitive pickup has transfer function $H(s)=sRC_c/(1+sRC_c)$ for a coupling capacitance feeding a resistive input. It emphasizes changes and suppresses low frequencies. In practice, conductor spacing, insulation, shielding, and nearby phases change $C_c$ and the common-mode pickup. This model is a proposed explanatory approximation, not a characterized sensor for the user's line. A capacitive pickup is attractive when contact is undesirable, but is not the first choice for absolute reflection amplitude or an unvalidated mains interface.

## 6.6 Simultaneous voltage and current

For a scalar real characteristic impedance, forward and reverse voltage waves can be reconstructed as

$$V^{\text{+}}=\frac{V+Z_0I}{2},\qquad V^{\text{-}}=\frac{V-Z_0I}{2}. \qquad (29)$$

This can help reject the incident wave and verify polarity. It requires voltage and current at the same reference plane, matched amplitude calibration, and accurate timing alignment. A frequency-dependent or modal characteristic impedance requires the corresponding frequency-domain or multiconductor operation, not multiplication by an arbitrary 50 Ω constant.

For a current-channel delay error $\delta t$, the false reverse-wave component near a pure incident edge is approximately $(\delta t/2)\,dV^{\text{+}}/dt$. Fast edges therefore amplify small deskew errors. The supplied example uses a 0.5 ns channel mismatch; the residual is an instrument artifact, not a line fault.

![Figure 4. Synthetic launch residual produced by a 0.5 ns voltage/current timing mismatch. The current channel is delayed before applying Equation (29). The example shows why separate sensor bandwidth specifications are not sufficient.](figures/04_deskew.png){width=6.1in}

**Selection conclusion.** Start with broadband voltage sensing through a calibrated reflectometry interface. Add an HFCT when current-wave information has a defined purpose. Choose a Rogowski coil only after proving that its full response and noise meet the pulse requirement. Neither a Hall-effect label nor a clamp form factor establishes suitability for nanosecond reflections.

# 7. Calibration and fault-location algorithm

## 7.1 Measurement model

A realistic sampled observation contains the launched waveform, network response, instrument response, feedthrough, and noise. A general model is

$$y_r(t)=g_r(t)*h_r(t;\boldsymbol\theta)*p(t)+d_r(t)+n_r(t), \qquad (30)$$

where $r$ denotes the measurement port or phase pair, $g_r$ is the calibrated instrument response, $h_r$ is the line/network response, $d_r$ is residual direct feedthrough, and $\boldsymbol\theta$ contains geometry and fault parameters. A forward model that includes source mismatch and internal delay is preferable to attributing every waveform feature to the line. [8]

The model is linear only while the line, fault, and interface behave linearly at the test amplitude and remain unchanged during acquisition. A moving contact or nonlinear fault can violate those assumptions. In that case, a single averaged trace may conceal rather than clarify the behavior.

## 7.2 Reference-plane and velocity calibration

Characterize the source, interface, and leads using safe low-voltage reference conditions. Known open, short, and suitable load conditions establish polarity, mismatch, and response shape. A VNA's open-short-load calibration and a pulse instrument's reference measurements are related ideas but are not the same correction algorithm. Full de-embedding should preserve the relevant complex transfer behavior. [2,13]

For two known lengths of the same uniform cable and the same selected propagation mode,

$$v=\frac{2(\ell_2-\ell_1)}{t_2-t_1},\qquad t_0=t_1-\frac{2\ell_1}{v}. \qquad (31)$$

The timing marker must be defined consistently, such as a fitted template delay. Measuring one trace at its leading threshold and another at its pulse maximum introduces a systematic difference. The uncertainties of $v$ and $t_0$ can be correlated when derived from the same calibration; that covariance belongs in the final uncertainty analysis.

A known-length open-end trace is useful, but a guessed velocity factor is not equivalent to calibration. The manufacturer's stated cursor accuracy can also be conditional on the correct velocity factor. [3]

## 7.3 Phase-pair test matrix

For the offline three-phase case, acquire L1–L2, L2–L3, and L3–L1 reflectograms with documented polarities. Where a neutral, armor, or screen exists and a safe approved arrangement permits it, additional phase-to-reference measurements may help. A phase-to-screen test is not interchangeable with a phase-to-phase test because the field geometry and return path differ. [1]

The nonselected conductors must have repeatable, documented terminations. They should not be left in an unknown mixture of connected loads, floating ends, and earth bonds. Protective earthing and isolation are controlled by the qualified test procedure; measurement convenience is not a reason to defeat them.

A fault involving L1 may affect both pairs containing L1, but coupled modes and connected terminations can spread the response further. Pair comparison is supporting evidence, not a complete conductor-classification rule without a model or controlled tests.

## 7.4 Baseline processing

Acquire a healthy reference whenever possible under the same cable configuration, terminations, and temperature range. Align records using the stable launch or reference feature, normalize only with justified gain calibration, and then compute the residual $r(t)=y_{\mathrm{new}}(t)-y_{\mathrm{healthy}}(t)$.

Do not globally warp the entire new trace to match the baseline, because a true change in propagation or an added discontinuity may be aligned away. A small baseline delay error gives a residual proportional to the derivative of the healthy trace, creating bipolar false events at otherwise normal joints. The processing log should retain both raw records and every alignment parameter.

Preprocessing should remove DC offsets and suppress known out-of-band interference without discarding the spectrum needed for timing. Coherent averaging is performed only after alignment. A clipping or overload flag invalidates affected samples; a filter cannot recover an echo that the analog receiver failed to acquire.

## 7.5 Signed matched filtering

For a calibrated sampled echo template $q$ and white sample noise of known standard deviation $\sigma_n$, define

$$z[k]=\frac{\sum_n r[n]q[n-k]}{\sigma_n\sqrt{\sum_nq^2[n]}}. \qquad (32)$$

Select candidate peaks in $|z[k]|$ outside known launch and fixture regions. Preserve the sign of $z$ for voltage-polarity interpretation. The delay estimate is the peak location, optionally refined by a local fit. For independent white Gaussian noise under the no-echo hypothesis, each normalized correlation has unit variance. A conservative multiple-search bound is

$$P_{\mathrm{FA}}\leq2KQ(\eta), \qquad (33)$$

where $K$ is the number of searched lags, $\eta$ is the two-sided threshold, and $Q$ is the standard-normal upper-tail probability. The union bound does not require independent lags, but the unit-variance Gaussian model and known noise level must hold. Real colored or impulsive noise requires a measured null distribution, whitening, or a different detector.

The detector estimates delay and signed amplitude jointly. Where attenuation or dispersion changes the echo shape substantially, use a distance-dependent template bank or fit the full forward model. A single short-cable pulse template can otherwise produce distance-dependent bias.

## 7.6 Regularized reconstruction

When a calibrated input spectrum $P(f)$ is available, a simple regularized transfer estimate is

$$\hat H(f)=\frac{Y(f)P^{\text{*}}(f)}{|P(f)|^2+\lambda(f)}. \qquad (34)$$

The regularization $\lambda(f)$ suppresses division by small spectral components. A rectangular pulse has spectral zeros; blind division by its spectrum amplifies noise near those zeros. Instrument-response correction may be included in the same model. Regularization controls instability but does not create information in an unmeasured or fully suppressed frequency band. Spectrum restrictions and reconstruction are also central to multicarrier reflectometry. [5]

## 7.7 Topology-aware classification

For an unbranched, approximately single-mode test, classify the earliest validated fault echo with the calibrated voltage convention. For a network, compare candidate forward responses across all acquired ports:

$$\hat{\boldsymbol\theta}=\arg\min_{\boldsymbol\theta}\sum_r\left\|\mathbf W_r\big[\mathbf y_r-\mathbf f_r(\boldsymbol\theta)\big]\right\|^2+\lambda_\theta\mathcal R(\boldsymbol\theta). \qquad (35)$$

Here $\mathbf W_r$ accounts for noise weighting and valid samples, while $\mathcal R$ can represent explicitly stated prior constraints. The hypotheses should include a healthy network, plausible faults, and plausible load/termination changes. An algorithm must be allowed to return “ambiguous branch” or “inconclusive” rather than force a precise label.

The reported result should include the selected port, likely fault type, electrical distance, candidate physical branch, uncertainty, pulse setting, and reasons for any ambiguity. The margin between the best and competing models is more informative than an unexplained confidence percentage.

# 8. Reproducible simulations and analytical results

## 8.1 Purpose and limits of the simulations

All figures and result tables in this section were generated for this paper by the supplied Python program. They are not measurements. The simulations isolate selected mechanisms so that the calculations are reproducible and their limitations are visible. They do not solve the full frequency-dependent multiconductor cable model, model a live 380 V supply, or include an approved mains coupler.

Two scalar models are used. The first is an event-scattering network with matched source, equal characteristic impedances, and ideal branch terminations. The second is a single-echo model with causal source/receiver filtering, a prescribed propagation delay, constant in-band attenuation, and independent additive sampled Gaussian noise. Constant attenuation is an illustrative approximation, not a fit to a particular cable.

## 8.2 Causal waveform model

The source is modeled by a first-order low-pass response with $\tau_g=5\ \mathrm{ns}/\ln9$. The receiver is a first-order 100 MHz system with $\tau_r=1/(2\pi\,100\ \mathrm{MHz})$. The cascade's unit-step response is

$$F(t)=\left[1-\frac{\tau_ge^{-t/\tau_g}-\tau_re^{-t/\tau_r}}{\tau_g-\tau_r}\right]u(t). \qquad (36)$$

The filtered pulse is $q(t)=F(t)-F(t-T_p)$. This explicitly preserves causality and distinguishes the source's 5 ns rise time from the slower combined response. For a hard fault at distance $x$, the single-echo observation is

$$y[n]=\Gamma_fV_i e^{-2\alpha x}q(nT_s-2x/v)+n[n]. \qquad (37)$$

The matched-filter template uses the same calibrated source/receiver shape. This deliberately favorable match means the results measure detector behavior under the assumed model, not robustness to unknown cable dispersion. Fractional true delay is preserved analytically before sampling; sub-sample estimation uses a parabolic fit around the signed correlation peak.

## 8.3 Simulation parameters

| Parameter | Value and meaning |
|:---|:---|
| Propagation speed | $1.7\times10^8$ m/s, assumed and known to the estimator |
| Sampling | 1 GS/s; 14,000 samples per Monte Carlo trace |
| Incident voltage | 1 V before the modeled source/receiver filtering |
| Source rise time | 5 ns, 10–90%, before receiver filtering |
| Receiver | Single pole, 100 MHz −3 dB bandwidth |
| One-way attenuation | 0.002 Np/m, constant over the modeled signal band |
| Monte Carlo fault position | 750 m; reflection coefficient +1 or −1 |
| Noise | 20 or 40 mV RMS; independent Gaussian noise added to samples |
| Pulse durations | 5, 10, 20, 50, 100, 200 ns |
| Search region | 50–950 m; not a narrow oracle window around the fault |
| Detection rule | Largest absolute normalized correlation at least 6 |
| Correct outcome | Detected, correct polarity, and distance error no greater than 2 m |
| Trial count | 500 per polarity, per width, per noise level; 12,000 total |
| Random seed | 3802026 |

The assumed unfiltered hard-fault return amplitude at 750 m is $e^{-3}=0.049787$ V. A very short pulse does not reach this full plateau after the two filters. Its waveform energy is also smaller, explaining the sharp loss of short-pulse detection probability in this deliberately attenuated example.

## 8.4 Detection results

| Width | Correct / 1,000 at 20 mV | Rate | Correct / 1,000 at 40 mV | Rate |
|---:|---:|---:|---:|---:|
| 5 ns | 23 | 2.3% | 0 | 0.0% |
| 10 ns | 744 | 74.4% | 6 | 0.6% |
| 20 ns | 1000 | 100.0% | 215 | 21.5% |
| 50 ns | 1000 | 100.0% | 1000 | 100.0% |
| 100 ns | 1000 | 100.0% | 1000 | 100.0% |
| 200 ns | 1000 | 100.0% | 1000 | 100.0% |

![Figure 5. Simulated correct-detection rates, including correct polarity and location within 2 m. Each point represents 1,000 traces: 500 opens and 500 shorts. These rates are conditional on the stated exact-template, scalar-line model.](figures/05_detection.png){width=6.1in}

At 20 mV RMS noise, a 20 ns pulse is the shortest tested duration with correct detection in all 1,000 simulated trials. At 40 mV RMS, the corresponding duration is 50 ns. This demonstrates an adaptive selection principle, not a recommended fixed duration for all 750 m cables. A different attenuation curve, launch amplitude, sensor response, or required false-alarm rate would shift these outcomes.

Observing 1,000 successes does not establish a population success probability of exactly 100%. The approximate “rule of three” gives an upper 95% one-sided failure-probability scale of about 0.3% when no failures are observed in 1,000 independent trials, and that statement still applies only to this simulated distribution.

## 8.5 Conditional location errors and their interpretation

| Width | Detected at 20 mV | 95th-percentile error | Detected at 40 mV | 95th-percentile error |
|---:|---:|---:|---:|---:|
| 5 ns | 23 | 0.117 m | 0 | Not defined |
| 10 ns | 744 | 0.138 m | 6 | 0.196 m |
| 20 ns | 1000 | 0.144 m | 215 | 0.221 m |
| 50 ns | 1000 | 0.143 m | 1000 | 0.341 m |
| 100 ns | 1000 | 0.146 m | 1000 | 0.343 m |
| 200 ns | 1000 | 0.139 m | 1000 | 0.352 m |

![Figure 6. The simulated 95th-percentile distance error among detected traces. Low-detection settings contain a strongly selected subset and must not be compared as if they represented all faults. No propagation-speed or model uncertainty is included.](figures/06_timing.png){width=6.1in}

Once detection is reliable, widening the pulse from 50 ns to 200 ns does not materially improve the edge-based timing precision. At 40 mV RMS, the 95th-percentile conditional error is roughly 0.34–0.35 m across these durations. This agrees with the derivative-energy argument in Equation (27): the plateau grows while edge information changes little.

At low detection rates, deceptively small conditional errors arise because only favorable noise realizations exceed the threshold. A useful system metric must therefore report misses alongside the error quantile. The 5 ns, 40 mV case has no detected traces and consequently has no conditional timing statistic; it is not assigned a zero error.

The detector searches approximately 10,588 lag positions. Equation (33) gives a no-fault union-bound scale of about $2.1\times10^{-5}$ per trace at threshold six under the assumed white-noise model. This is an analytic bound, not an experimentally established false-alarm rate. A dedicated healthy-cable/null-data campaign remains necessary.

## 8.6 Network and instrument checks

The network code aggregates coincident arrivals before applying the junction scattering equation and includes repeated returns up to the stated path-length limit. It checks the healthy junction coefficient $-1/3$, the first open-branch coefficient $4/9$, the first short coefficient $-4/9$, and conservation of energy at the equal-impedance lossless junction. Those tests establish internal consistency for the modeled network, not validity of its parameters for a physical feeder.

Figure 2 confirms that the first negative event in the branched network is not the short fault: it is the healthy junction. Figure 4 confirms that a V/I timing mismatch creates a false reverse-wave signal even with no physical fault. The two mechanisms can coexist in an instrument and must be handled separately.

## 8.7 What these results do and do not establish

The simulations support the pulse-energy trade-off, the need to distinguish conditional timing from detection, and the existence of multiple-path artifacts. The modal-speed and parallel-symmetry conclusions are analytical results rather than numerical validation of a particular three-phase cable.

The results do not establish achievable range, minimum detectable fault resistance, field accuracy, immunity to inverter noise, or safe online operation. Those claims require measured RLGC or S-parameter data, representative fixtures, verified topology, and independent validation. This boundary is essential because the sub-meter synthetic timing errors can coexist with multi-meter physical-distance errors from velocity uncertainty alone.

# 9. Experimental validation, uncertainty, and safety

## 9.1 Proposed offline validation sequence

Begin with an entirely isolated low-voltage fixture, not an operating feeder. Verify the source, reference plane, voltage channel, and optional current channel on known terminations. Then test a single cable of measured length, followed by the actual three-phase cable geometry with documented nonselected-conductor terminations. Introduce controlled open and short boundaries through suitable low-voltage fixtures rather than damaging a service cable.

Next, construct a documented branch network and repeat the tests with known junctions, multiple lengths, and controlled series or shunt resistances. Finally, evaluate additional ports and deliberately symmetric branches to determine when branch identification becomes possible. A single source-port experiment that succeeds only on asymmetric examples does not validate a universal parallel-feeder locator.

All tests should preserve raw waveform data, calibration files, fixture photographs or drawings, environmental conditions, and configuration identifiers. Independent physical distance measurements establish the reference values. The commercial TDR or other reference instrument must itself be configured with the correct propagation factor and documented uncertainty.

## 9.2 Test matrix and ablations

| Factor | Proposed controlled variation | Main question |
|:---|:---|:---|
| Distance | Near end, intermediate positions, far end | Blind zone, attenuation, and distance-dependent bias |
| Fault type | Open; hard short; several local shunt/series resistances | Detection and classification boundaries |
| Pulse width | Full selectable sweep | Energy versus overlapping-event interpretation |
| Geometry | Phase-pair choice, cable arrangement, screen/return choice | Coupling and modal sensitivity |
| Topology | Unbranched, T-junction, parallel buses, unequal/equal paths | Branch identifiability and ghost echoes |
| Processing | Raw timing, matched filter, baseline subtraction, topology model | Contribution of each processing stage |
| Noise | Quiet baseline, recorded interference, repeatable injected interference | False alarms and detection robustness |
| Sensors | Voltage only, HFCT-assisted, controlled V/I deskew error | Benefit and calibration burden of current sensing |

The experimental sample count must be chosen from the precision needed for detection and false-alarm estimates, not only convenience. Fault locations and cable sections used for calibration should be separated from held-out validation cases. A machine-learning extension additionally requires held-out cable configurations; random splitting of nearly identical traces from the same setup can greatly overstate generalization.

Report misses and wrong branches explicitly. Suitable metrics include false alarms per trace, correct classification among all test cases, correct branch identification, median and 95th-percentile distance error, and acquisition time. Use confidence intervals for proportions, and keep uncalibrated physical-distance errors separate from repeatability on one fixed fixture.

## 9.3 Uncertainty budget

For $x=v\tau/2$, first-order propagation with independent inputs gives

$$u_x^2=\left(\frac{\tau}{2}u_v\right)^2+\left(\frac{v}{2}u_\tau\right)^2+u_{\mathrm{fixture}}^2+u_{\mathrm{model}}^2. \qquad (38)$$

This follows the law of propagation of standard uncertainty. Where inputs are correlated, use the full covariance expression $u_x^2=\mathbf J\mathbf\Sigma\mathbf J^T$ and additional justified terms. Calibration covariance must not be ignored merely to obtain a simple sum. [16]

Assume, only for illustration, $x=750$ m, standard relative speed uncertainty 0.5%, standard delay uncertainty 1 ns, and fixture-distance uncertainty 0.10 m, with no separately quantified model term. The speed contribution is 3.75 m, the timing contribution is 0.085 m, and their combined standard uncertainty is approximately 3.752 m. A coverage factor near two would give an approximate 7.5 m expanded uncertainty only under a justified distribution and coverage model.

This is much larger than the conditional synthetic timing errors in Section 8. The comparison explains why improving an interpolated cursor is not enough. Unknown branch identity is not well represented by a small Gaussian error bar: it is a discrete ambiguity that should be reported as competing physical hypotheses.

Systematic biases should be corrected where possible, with uncertainty assigned to the correction. Averaging reduces repeatable random noise but not an incorrect velocity factor, wrong reference plane, or wrong topology. The resulting distance is along the electrical route; locating the corresponding ground position requires a separate route map or tracing procedure.

## 9.4 Electrical-safety boundary

A low test-pulse amplitude does not make a connected 380 V circuit safe. The assumed offline workflow requires a qualified person to establish the applicable isolation and lockout procedure, address all sources and backfeed paths, verify absence of voltage with appropriate equipment, and deal with stored or induced energy. OSHA 1910.333 provides an authoritative example of de-energization and verification requirements; the applicable jurisdiction and site procedure may impose additional obligations. [15]

No laboratory pulse generator, ordinary oscilloscope input, low-voltage active probe, or unqualified homemade capacitive coupler is specified here for direct live-line connection. A high-frequency magnetic sensor may provide non-galvanic signal coupling but still needs appropriate working-voltage, insulation, current, and installation-category suitability. Sensor aperture and physical spacing do not by themselves certify safety.

Commercial instruments differ. The cited Megger documentation distinguishes models and specifically describes the TDR2050's rated energized-system capability; this must not be generalized to all TDRs or to a custom interface. Rated leads and the manufacturer's complete instructions remain part of the system. The present proposed research setup remains offline. [3]

Any future online version requires a separate interface design review covering insulation coordination, common-mode transients, protective devices, EMC, fault energy, and single-failure behavior. That work is outside the evidence established by these simulations.

# 10. Discussion and conclusions

## 10.1 Recommended research direction

Begin with an offline voltage reflectometer: a calibrated launch plane, adjustable pulses, a characterized broadband receiver, and sufficient sampling rate. Optional HFCT sensing adds wave-separation information but requires gain, polarity, and deskew calibration. Select sensors by reflected-pulse amplitude and spectrum, not service-frequency current alone.

For the declared examples, initial laboratory targets are approximately 5 ns source rise time, a 100 MHz end-to-end analog path, and a 1 GS/s digitizer. These are proposed targets, not validated minimum specifications for every cable. Sweep pulse duration against measured detection and separation objectives.

Define the conductor pair, return path, and nonselected-conductor terminations before collecting data. Replace the scalar approximation with a multiconductor model when phase-pair responses or modal arrivals require it. Branched or electrically parallel paths may need branch-specific measurement access.

## 10.2 Answers to the research questions

Pulse duration governs energy and overlap; edge speed and total measurement response govern timing information. Widening a pulse can rescue detection without continuing to improve timing precision. The nominal 380 V rating therefore does not determine one best duration.

Calibrated broadband voltage sensing is the preferred primary measurement. A sufficiently fast HFCT is the leading optional current transducer. Rogowski systems and capacitive pickups remain conditional alternatives requiring transfer-function and sensitivity validation. Ordinary service-frequency instrumentation is not an adequate default.

Open/short polarity rules are exact for ideal scalar terminations. Local shunts, series faults, damaged sections, branch junctions, and converted modes need their own models. A negative junction reflection alone is not evidence of a short.

Symmetric parallel paths can make distinct faults indistinguishable at an accessible common port. Additional measurement access or safe branch isolation can provide missing information; algorithmic complexity cannot remove an exact measurement symmetry.

## 10.3 Research status and next development step

This paper provides theory, executable illustrative simulations, and a validation plan—not cable-specific empirical accuracy or a safety-qualified energized-line instrument. Numerical targets must be revised for the actual length, construction, grounding, topology, and required tolerance.

The decisive next step is to characterize an isolated sample of the actual cable using the intended phase-pair connection. Measured echo shape and propagation delay should replace the illustrative parameters before selecting a final pulse duration or claiming location accuracy.

# Appendix A. Worked initial design example

Consider an assumed offline, unbranched 300 m cable test with a desired ability to inspect events separated by about 2 m. Let $v=1.7\times10^8$ m/s. The direct far-end round-trip delay is $2(300)/v=3.529$ μs. A 6 μs initial record leaves space for the launch and first far-end return, but should be extended if important re-reflections remain.

The simple nonoverlap condition gives $T_p\lesssim2(2)/v=23.53$ ns. A 20 ns pulse is therefore a justified *first trial* for that interpretation objective, not a guaranteed optimum. Its 1.7 m pulse-overlap scale should be distinguished from the effective edge response and the actual ability to resolve unequal or opposite-polarity echoes.

A 100 MHz single-pole receiver contributes approximately 3.5 ns of transition time. Combined with a 5 ns source, an approximate root-sum-square scale is 6.1 ns, equivalent to about 0.52 m. This estimate does not include cable dispersion, bridge ringing, or probe loading. A 1 GS/s digitizer provides a 0.085 m raw distance increment, while a 0.5% velocity error at 300 m already causes a 1.5 m distance bias.

For a simple 50 Ω matched test model, a 2 V open-circuit Thevenin source launches approximately 1 V into the line. The corresponding incident current is approximately 20 mA. These values explain why a low-noise voltage receiver or sensitive HFCT is more relevant than a high-current industrial clamp. The 50 Ω line impedance is only an example; the actual selected cable port must be characterized.

If the 20 ns far-end echo is too weak, first assess averaging, fixture loss, source matching, gain, and sensor noise. Compare 50 ns and 100 ns traces to establish whether added energy reveals the event, then return to a narrower or coded waveform where separation is needed. Do not interpret a gain change or waveform-dependent peak shift as a physical change in fault position.

# Appendix B. Reproduction and data provenance

The supplemental package contains `simulate_tdr.py`, the generated `results/monte_carlo.csv` and `results/summary.json`, figure files, and a dependency list. The script performs causal waveform generation, exact equal-impedance junction scattering, analytical sanity checks, and the 12,000-trace Monte Carlo sweep. No internet connection or instrument is required after the Python dependencies are available.

Run the following in the directory containing the script:

```text
python -m pip install -r requirements.txt
python simulate_tdr.py
```

The fixed seed is 3802026. Small numerical differences across library versions or platforms may occur, especially around an exact detection threshold. The reference output files document the run used in this paper. The assumptions are exposed as constants and function arguments so that a measured velocity, attenuation approximation, or noise level can be substituted. Changing a constant does not turn the scalar simulation into a multiconductor or safety-qualified hardware model.

The source manuscript is included as Markdown. The Word document uses editable equations and structured headings. Literature claims refer to the numbered sources below; all figures and numerical examples in this paper are generated calculations, not reproduced experimental data from those references. Manufacturer examples illustrate specifications and limitations rather than product purchasing endorsements.

# References

[1] BAUR GmbH. “Time domain reflectometry (TDR): Cable fault pre-location method.” Manufacturer technical explanation. Accessed 11 October 2026. https://www.baur.eu/en/products/cable-fault-location/cable-fault-location-process/time-domain-reflectometry

[2] Keysight Technologies. *High Precision Time Domain Reflectometry (TDR).* Application note 5988-9826. Manufacturer discussion of measurement response, fixtures, and differential measurements. Accessed 11 October 2026. https://www.keysight.com/us/en/assets/7018-01179/application-notes-archived/5988-9826.pdf

[3] Megger. *TDR2000/3, TDR2010 and TDR2050: Advanced Dual Channel TDR.* Manufacturer data sheet, four-page version linked from the product support page. Accessed 11 October 2026. https://www.megger.com/en/products/tdr2000/3-and-tdr2010

[4] P. Smith, C. Furse, and J. Gunther. “Analysis of Spread Spectrum Time Domain Reflectometry for Wire Fault Location.” *IEEE Sensors Journal*, vol. 5, no. 6, pp. 1469–1478, December 2005. doi:10.1109/JSEN.2005.858964. https://doi.org/10.1109/JSEN.2005.858964

[5] A. Lelong and M. O. Carrion. “On Line Wire Diagnosis using Multicarrier Time Domain Reflectometry for Fault Location.” *IEEE SENSORS 2009*, pp. 751–754, 2009. Conference paper, university-hosted copy. https://warwick.ac.uk/fac/sci/eng/research/grouplist/sensorsanddevices/mbl/database/ieeesensors09/PDFs/Papers/172_5184.pdf

[6] E. Song, Y.-J. Shin, P. E. Stone, J. Wang, T.-S. Choe, J.-G. Yook, and J. B. Park. “Detection and location of multiple wiring faults via time-frequency-domain reflectometry.” *IEEE Transactions on Electromagnetic Compatibility*, vol. 51, no. 1, pp. 131–138, 2009. doi:10.1109/TEMC.2008.2007964. University publication record and abstract consulted. https://doi.org/10.1109/TEMC.2008.2007964

[7] O. Osman, S. Sallem, L. Sommervogel, M. Olivas Carrion, P. Bonnet, and F. Paladian. “Distributed Sensor Diagnosis in Twisted Pair Networks for Soft Fault Identification Using Reflectometry and Neural Network.” *Progress In Electromagnetics Research C*, vol. 100, pp. 83–93, 2020. doi:10.2528/PIERC19122402. https://www.jpier.org/issues/volume.html?paper=19122402

[8] S. R. Schuet, D. A. Timucin, and K. R. Wheeler. “A Model-Based Probabilistic Inversion Framework for Wire Fault Detection Using TDR.” NASA Ames Research Center, 2010; NTRS document 20100027330, four-page conference manuscript. https://ntrs.nasa.gov/api/citations/20100027330/downloads/20100027330.pdf

[9] Tektronix. *TDP1000, TDP0500, P6251: 1 GHz and 500 MHz High Voltage Differential Probes.* Manufacturer data sheet. Accessed 11 October 2026. https://www.tek.com/en/datasheet/1-ghz-and-500-mhz-high-voltage-differential-probes

[10] Pearson Electronics. *Current Monitor Model 2877.* Manufacturer specification 2877.SPX_990506, 1999. Accessed 11 October 2026. https://pearsonelectronics.com/pdf/2877.pdf

[11] Pearson Electronics. “Rise Time.” Manufacturer application note. Accessed 11 October 2026. https://www.pearsonelectronics.com/support/application-notes/rise-time

[12] Power Electronic Measurements Ltd. “CWTMini50HF AC Rogowski Coil Current Probe.” Manufacturer specifications, including bandwidth, rise time, and output loading. Accessed 11 October 2026. https://www.pemuk.com/products/cwt-range/cwtmini50hf

[13] Keysight Technologies. “Time Domain.” Vector network analyzer online help: transforms, response resolution, windowing, and aliasing. Accessed 11 October 2026. https://helpfiles.keysight.com/csg/pxivna/Time/TimeDomain.htm

[14] Tektronix. *Understanding Oscilloscope Bandwidth, Rise Time and Signal Fidelity.* Manufacturer technical note, university-hosted copy. Accessed 11 October 2026. https://people.ece.ubc.ca/robertor/Links_files/Files/TEK-Understanding-Scope-BW-tr-Fidelity.pdf

[15] Occupational Safety and Health Administration. “29 CFR 1910.333: Selection and use of work practices.” Official regulatory text, especially de-energization and verification provisions. Accessed 11 October 2026. https://www.osha.gov/laws-regs/regulations/standardnumber/1910/1910.333

[16] Joint Committee for Guides in Metrology. *Evaluation of measurement data—Guide to the expression of uncertainty in measurement*, JCGM 100:2008. Section 5, “Determining combined standard uncertainty,” official ISO-hosted text. https://www.iso.org/sites/JCGM/GUM/JCGM100/C045315e-html/C045315e_FILES/MAIN_C045315e/05_e.html
