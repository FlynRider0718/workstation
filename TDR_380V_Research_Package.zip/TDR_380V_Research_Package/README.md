# Three-Phase 380 V Low-Voltage Pulse Reflectometry

## Research package

This package accompanies **Fault Detection and Localization in Three-Phase 380 V Parallel Power Lines: Low-Voltage Pulse Reflectometry (Radar Method)**, prepared for Nata on 11 October 2026.

The paper contains 34 pages, 38 displayed equations, six original simulation figures, 16 numbered references, and an offline experimental-validation plan. It is a theoretical study with explicitly assumed numerical parameters. It is not an approved university thesis, measured field-performance report, or safety-qualified live-line instrument design.

## Files

- `TDR_380V_Masters_Theory.pdf`: paginated reading/printing version.
- `TDR_380V_Masters_Theory.docx`: editable text, tables, native Word equations, and figures. The linked contents page reflects the supplied pagination; revise its page numbers after layout changes.
- `manuscript.md`: readable Markdown source, including equations and references.
- `simulate_tdr.py`: executable simulation and analytical sanity checks.
- `requirements.txt`: exact NumPy, SciPy, and Matplotlib versions from the reference run.
- `reference_environment.json`: Python version and run provenance.
- `results/monte_carlo.csv`: trial counts and summary statistics for all 12 width/noise settings.
- `results/summary.json`: simulation parameters, theoretical false-alarm bound, and results.
- `figures/`: all six figures in PNG and scalable SVG formats. The filenames follow generation order; manuscript figure numbering is recorded below.
- `SHA256SUMS.txt`: checksums of package files other than the checksum file itself.

## Reproduce the calculations

The reference run used Python 3.13.5. Create a Python environment, open a terminal in this package directory, and run:

```text
python -m pip install -r requirements.txt
python simulate_tdr.py
```

Installing dependencies may require internet access. Once dependencies are available, the simulation itself runs offline and connects to no instruments or external services. Running it regenerates files under `figures/` and `results/`; preserve a copy of the supplied reference outputs before modifying the assumptions.

The script evaluates 12,000 synthetic traces with seed 3802026: six pulse durations, two sampled-noise levels, 500 open-fault traces and 500 short-fault traces at each setting. The output includes the fraction correctly detected with the correct polarity and location within 2 m. The 95th-percentile errors are conditional on detection and exclude propagation-speed, geometry, and calibration uncertainty. They are not field-accuracy specifications.

## Model scope

The simulations include a causal two-pole source/receiver response, an assumed scalar-line attenuation, signed matched filtering, a matched-source scalar three-port junction with repeated echoes, and a voltage/current deskew example. The multiconductor model and symmetric-parallel-feeder identifiability argument are analytical parts of the paper, not a complete three-phase electromagnetic simulation in the code.

Noise is independent Gaussian noise added at the sampling stage. The received template and propagation speed are assumed known. Frequency-dependent cable loss, dispersive mode conversion, unknown loads, impulsive mains interference, near-end saturation, and energized coupling are not validated by these runs.

Small numerical differences can occur across library versions and platforms. Check the supplied CSV/JSON for the exact results used in the paper.

## Figure mapping

| Figure in paper | File stem |
|:---|:---|
| 1: open/short reflections | `01_open_short` |
| 2: branched-network reflections | `03_branched_network` |
| 3: pulse overlap | `02_pulse_overlap` |
| 4: voltage/current timing mismatch | `04_deskew` |
| 5: correct-detection rates | `05_detection` |
| 6: conditional location errors | `06_timing` |

## Safety and interpretation

The proposed baseline is testing a line that qualified personnel have isolated and verified de-energized, with stored energy and backfeed addressed. Do not directly connect a laboratory generator, ordinary oscilloscope, or low-voltage probe to an energized 380 V power line on the basis of this paper.

A low-amplitude test pulse does not certify the connected circuit as safe. A normal-looking reflectogram does not exclude all insulation or voltage-dependent faults. The actual conductor geometry, grounding, feeder topology, calibration, instrument ratings, and site safety procedure must be established before testing.

The manufacturer and research sources are listed in the paper. All supplied plots and numerical results are generated illustrations, not borrowed experimental measurements.
